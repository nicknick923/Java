
/**

 @author Jake Ira
 */
import java.util.Scanner;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import jdk.nashorn.internal.parser.TokenType;

public class FractionManipulator
{

   private Scanner stdin;
   private ListOfFraction myList = new ListOfFraction();

   public void run() throws java.io.IOException
   {
      stdin = new Scanner(System.in);
      String command = stdin.next();
      while (!command.equalsIgnoreCase("Q"))
      {
         if (command.equalsIgnoreCase("A"))
            add();
         else if (command.equalsIgnoreCase("D"))
            delete();
         else if (command.equalsIgnoreCase("M"))
            multiply();
         else if (command.equalsIgnoreCase("P"))
            print();
         else if (command.equalsIgnoreCase("S"))
            sum();
         else
            System.out.println(command + " is not a valid command!");
         command = stdin.next();
      }
      System.out.println("Normal Termination of Program 2!");
   }

   private void add()
   {
      Fraction newFraction = new Fraction(stdin.next());
      myList.add(newFraction);
      System.out.println(newFraction + " was added to the list.");

   }

   private void delete()
   {
      Fraction newFraction = new Fraction(stdin.next());
      if (myList.delete(newFraction))
         System.out.println(newFraction + " was removed from the list.");
      else
         System.out.println(newFraction + " is not in the list.");
   }

   private void print()
   {
      int numPerLine = stdin.nextInt();
      System.out.println("The numbers in the list are:");
      myList.print(numPerLine);
   }

   private void multiply()
   {
      System.out.println("The product of the list is: " + myList.product());
   }

   private void sum()
   {
      System.out.println("The sum of the list is: " + myList.sum());
   }
}
